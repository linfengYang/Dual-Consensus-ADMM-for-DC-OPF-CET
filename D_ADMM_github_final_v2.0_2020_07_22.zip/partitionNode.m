%% ***************************************************************
%             Author��Lingfeng Yang,Jiangyao Luo,Yan Xu,Zhenrong Zhang,Zhaoyang Dong
%             Email��ylf@gxu.edu.cn,landiljy@163.com
%             Start date:2017.12.7
%             Finish date:2017.12.28
%             Function description: Partition for DC-DOPF-CET
%% ***************************************************************
function [ PI, allNodes,PINumber ] = partitionNode( N, n, best_partition,partionMethod )

    if best_partition == 1
        %6-bus system
        if N == 6           
            if partionMethod == 1  %The first partition strategy;ԭ�ȵĻ��ַ�ʽһ�����֧·2��
                PI{1} = [1,2,4]'; %Corresponding to the Area A1 in Fig.2.
                PI{2} = [3,5,6]'; %Corresponding to the Area A2 in Fig.2.
                PINumber{1} = [1]; %PINumber{n} - PINumber{n-1} is the number of bus in PI{n-1}.
                PINumber{2} = [4];
                PINumber{3} = [7];
            elseif partionMethod == 2  % ��Ӧ�����е�6-bus. Corresponding to the 6-bus system in literature
                PI{1} = [1]';
                PI{2} = [2]';
                PI{3} = [3]';
                PI{4} = [4]';
                PI{5} = [5]';
                PI{6} = [6]';
                PINumber{1} = [1];
                PINumber{2} = [2];
                PINumber{3} = [3];
                PINumber{4} = [4];
                PINumber{5} = [5];
                PINumber{6} = [6];
                PINumber{7} = [7];
            elseif partionMethod == 3  %A fully-decentralized consensus-based ADMM approach for DC-OPF with demand response�е�6�ڵ����ӵ�Case1
                PI{1} = [1,6]';
                PI{2} = [2,3,4,5]';
                PINumber{1} = [1];
                PINumber{2} = [3];
                PINumber{3} = [7];
            elseif partionMethod == 4  %A fully-decentralized consensus-based ADMM approach for DC-OPF with demand response�е�6�ڵ����ӵ�Case2
                PI{1} = [1,2,6]';
                PI{2} = [3,4,5]';
                PINumber{1} = [1];
                PINumber{2} = [4];
                PINumber{3} = [7];
            end
        end

        %30-bus system
        if N == 30   
            if partionMethod == 1  %ԭ�ȵĻ��ַ�ʽһ�����֧·4����2��Ƭ��   �����е�Case1
                PI{1} = [1:8,25:30]';
                PI{2} = [9:24]';
                PINumber{1} = [1];
                PINumber{2} = [15];
                PINumber{3} = [31];
            elseif partionMethod == 2  %ԭ�ȵĻ��ַ�ʽ�������֧·7����3��Ƭ��    �����е�Case2
                PI{1} = [1:8,25:30]';
                PI{2} = [9:20]';
                PI{3} = [21:24]';
                PINumber{1} = [1];
                PINumber{2} = [15];
                PINumber{3} = [27];
                PINumber{4} = [31];
            elseif partionMethod == 4 %ԭ�ȵĻ��ַ�ʽ�������֧·9����3��Ƭ��    �����е�Case4
                PI{1} = [1:10]';
                PI{2} = [11:20]';
                PI{3} = [21:30]';
                PINumber{1} = [1];
                PINumber{2} = [11];
                PINumber{3} = [21];
                PINumber{4} = [31];
            end
        end

        %48-bus system
        if N == 48
            if partionMethod == 1
                PI{1} = [1:24]';
                PI{2} = [25:48]';
                PINumber{1} = [1];
                PINumber{2} = [25];
                PINumber{3} = [49];
            end
        end

        %118-bus system
        if N == 118
            if partionMethod == 3   %��ӦA Fully-Decentralized Consensus-Based ADMM Approach for DC-OPF With Demand Response�е�118���ӵĻ��ַ���Case 1
                PI{1} = [1:32,113:115,117]';
                PI{2} = [33:73,116]';
                PI{3} = [74:112,118]';
                PINumber{1} = [1];
                PINumber{2} = [37];
                PINumber{3} = [79];
                PINumber{4} = [119];
            elseif partionMethod == 4   %A Fully-Decentralized Consensus-Based ADMM Approach for DC-OPF With Demand Response��Case 2
                PI{1} = [1:7,11:15,33:37,39:64,117]';
                PI{2} = [8:10,16:32,38,65:82,96:99,113:116,118]';
                PI{3} = [83:95,100:112]';
                PINumber{1} = [1];
                PINumber{2} = [45];
                PINumber{3} = [93];
                PINumber{4} = [119];
            elseif partionMethod == 5   %A Fully-Decentralized Consensus-Based ADMM Approach for DC-OPF With Demand Response��Case 3
                PI{1} = [1:32,113:115,117]';
                PI{2} = [33:67]';
                PI{3} = [68:81,116,118]';
                PI{4} = [82:112]';
                PINumber{1} = [1];
                PINumber{2} = [37];
                PINumber{3} = [72];
                PINumber{4} = [88];
                PINumber{5} = [119];
            end
        end

        %1062-bus system
        if N == 1062
            if partionMethod == 2   
                PI{1} = [1:118]';
                PI{2} = [119:236]';
                PI{3} = [237:354]';
                PI{4} = [355:472]';
                PI{5} = [473:590]';
                PI{6} = [591:708]';
                PI{7} = [709:826]';
                PI{8} = [827:944]';
                PI{9} = [945:1062]';
                PINumber{1} = [1];
                PINumber{2} = [119];
                PINumber{3} = [237];
                PINumber{4} = [355];
                PINumber{5} = [473];
                PINumber{6} = [591];
                PINumber{7} = [709];
                PINumber{8} = [827];
                PINumber{9} = [945];
                PINumber{10} = [1063];
            end
        end

    else
        PI = cell(n,1);
        %%�����ǶԻ�������������
        % index = randint(1,N,[1 n]);
        % for j = 1:n
        %     index_j = find(index == j);
        %     PI{j} = index_j;
        % end


        %�����ǶԻ�����н�����Ȼ���
        for j = 1:n
            PI{j} = [j:n:N]';
        end

    end

    PI = PI';

    allNodes = [];
    for i = 1:size(PI,1)
        allNodes = [allNodes; PI{i}];
    end
end
