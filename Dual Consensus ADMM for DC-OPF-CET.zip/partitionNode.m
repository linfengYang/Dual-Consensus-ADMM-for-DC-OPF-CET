function [ PI, allNodes,PINumber ] = partitionNode( N, n, best_partition )
% ��� {1,...,N} ��һ�����֣��Ӽ�����Ϊn��
%PI{i}Ϊ��i��Ƭ���Ľڵ㼯��
%PINumber{i+1}-PINumber{i}-1Ϊ��i��Ƭ���Ľڵ�����

if best_partition == 1
    
%     if N == 3           %����
%         PI{1} = [1]';
%         PI{2} = [2]';
%         PI{3} = [3]';
%         PINumber{1} = [1];
%         PINumber{2} = [2];
%         PINumber{3} = [3];
%         PINumber{4} = [4];
%     end
    
%     if N == 6           %���ַ�ʽһ�����֧·2��
%         PI{1} = [1,2,4]';
%         PI{2} = [3,5,6]';
%         PINumber{1} = [1];
%         PINumber{2} = [4];
%         PINumber{3} = [7];
%     end
    
    if N == 6           %���ַ�ʽ�������֧·7��
        PI{1} = [1]';
        PI{2} = [2]';
        PI{3} = [3]';
        PI{4} = [4]';
        PI{5} = [5]';
        PI{6} = [6]';
        PINumber{1} = [1];
        PINumber{2} = [2];
        PINumber{3} = [3];
        PINumber{4} = [4];
        PINumber{5} = [5];
        PINumber{6} = [6];
        PINumber{7} = [7];
    end

%     if N == 6           %���ַ�ʽ�������֧·3��
%         PI{1} = [1,2,3]';
%         PI{2} = [4,5,6]';
%         PINumber{1} = [1];
%         PINumber{2} = [4];
%         PINumber{3} = [7];
%     end

%     if N == 6           %���ַ�ʽ�ģ����֧·5��
%         PI{1} = [1,2]';
%         PI{2} = [3,4]';
%         PI{3} = [5,6]';
%         PINumber{1} = [1];
%         PINumber{2} = [3];
%         PINumber{3} = [5];
%         PINumber{4} = [7];
%     end

%     if N == 30   %��Ĭ�ϣ����ַ�ʽһ�����֧·4��
%         PI{1} = [1]';
%         PI{2} = [2]';
%         PI{3} = [3]';
%         PI{4} = [4]';
%         PI{5} = [5]';
%         PI{6} = [6]';
%         PI{7} = [7]';
%         PI{8} = [8]';
%         PI{9} = [9]';
%         PI{10} = [10]';
%         PI{11} = [11]';
%         PI{12} = [12]';
%         PI{13} = [13]';
%         PI{14} = [14]';
%         PI{15} = [15]';
%         PI{16} = [16]';
%         PI{17} = [17]';
%         PI{18} = [18]';
%         PI{19} = [19]';
%         PI{20} = [20]';
%         PI{21} = [21]';
%         PI{22} = [22]';
%         PI{23} = [23]';
%         PI{24} = [24]';
%         PI{25} = [25]';
%         PI{26} = [26]';
%         PI{27} = [27]';
%         PI{28} = [28]';
%         PI{29} = [29]';
%         PI{30} = [30]';
%         PINumber{1} = [1];
%         PINumber{2} = [2];
%         PINumber{3} = [3];
%         PINumber{4} = [4];
%         PINumber{5} = [5];
%         PINumber{6} = [6];
%         PINumber{7} = [7];
%         PINumber{8} = [8];
%         PINumber{9} = [9];
%         PINumber{10} = [10];
%         PINumber{11} = [11];
%         PINumber{12} = [12];
%         PINumber{13} = [13];
%         PINumber{14} = [14];
%         PINumber{15} = [15];
%         PINumber{16} = [16];
%         PINumber{17} = [17];
%         PINumber{18} = [18];
%         PINumber{19} = [19];
%         PINumber{20} = [20];
%         PINumber{21} = [21];
%         PINumber{22} = [22];
%         PINumber{23} = [23];
%         PINumber{24} = [24];
%         PINumber{25} = [25];
%         PINumber{26} = [26];
%         PINumber{27} = [27];
%         PINumber{28} = [28];
%         PINumber{29} = [29];
%         PINumber{30} = [30];
%         PINumber{31} = [31];
%     end
    
    if N == 30   %��Ĭ�ϣ����ַ�ʽһ�����֧·4����2��Ƭ��
        PI{1} = [1:8,25:30]';
        PI{2} = [9:24]';
        PINumber{1} = [1];
        PINumber{2} = [15];
        PINumber{3} = [31];
    end
    
%     if N == 30   %���ַ�ʽ�������֧·9��
%         PI{1} = [1:15]';
%         PI{2} = [16:30]';
%         PINumber{1} = [1];
%         PINumber{2} = [16];
%         PINumber{3} = [31];
%     end
%     
%     if N == 30   %���ַ�ʽ�������֧·9����3��Ƭ��
%         PI{1} = [1:10]';
%         PI{2} = [11:20]';
%         PI{3} = [21:30]';
%         PINumber{1} = [1];
%         PINumber{2} = [11];
%         PINumber{3} = [21];
%         PINumber{4} = [31];
%     end
    
%     if N == 30   %���ַ�ʽ�ģ����֧·6��
%         PI{1} = [1:13,16,17,25:30]';
%         PI{2} = [14,15,18:24]';
%         PINumber{1} = [1];
%         PINumber{2} = [22];
%         PINumber{3} = [31];
%     end

%     if N == 30   %���ַ�ʽ�壬���֧·9����4��Ƭ��
%         PI{1} = [1:8]';
%         PI{2} = [9:20]';
%         PI{3} = [21:24]';
%         PI{4} = [25:30]';
%         PINumber{1} = [1];
%         PINumber{2} = [9];
%         PINumber{3} = [21];
%         PINumber{4} = [25];
%         PINumber{5} = [31];
%     end

%     if N == 30   %���ַ�ʽ�������֧·7����3��Ƭ��
%         PI{1} = [1:8,25:30]';
%         PI{2} = [9:20]';
%         PI{3} = [21:24]';
%         PINumber{1} = [1];
%         PINumber{2} = [15];
%         PINumber{3} = [27];
%         PINumber{4} = [31];
%     end

%     if N == 30   %���ַ�ʽ�ߣ����֧·10����3��Ƭ��
%         PI{1} = [1:5]';
%         PI{2} = [6:11]';
%         PI{3} = [12:30]';
%         PINumber{1} = [1];
%         PINumber{2} = [6];
%         PINumber{3} = [12];
%         PINumber{4} = [31];
%     end


    if N == 118
        PI{1} = [1:32, 70:75,113:115,117]';
        PI{2} = [33:69, 76:81, 97:99, 116, 118 ]';
        PI{3} = [82:96, 100:112]';
        PINumber{1} = [1];
        PINumber{2} = [43];
        PINumber{3} = [91];
        PINumber{4} = [119];
    end

%     if N == 60
%         PI{1} = [1:30]';
%         PI{2} = [31:60]';
%         PINumber{1} = [1];
%         PINumber{2} = [31];
%         PINumber{3} = [61];
%     end
%     
%     if N == 90
%         PI{1} = [1:30]';
%         PI{2} = [31:60]';
%         PI{3} = [61:90]';
%         PINumber{1} = [1];
%         PINumber{2} = [31];
%         PINumber{3} = [61];
%         PINumber{4} = [91];
%     end
%     
%     if N == 120
%         PI{1} = [1:30]';
%         PI{2} = [31:60]';
%         PI{3} = [61:90]';
%         PI{4} = [91:120]';
%         PINumber{1} = [1];
%         PINumber{2} = [31];
%         PINumber{3} = [61];
%         PINumber{4} = [91];
%         PINumber{5} = [121];
%     end
    
%     if N == 600       %��ʽһ
%         PI{1} = [1:30]';
%         PI{2} = [31:60]';
%         PI{3} = [61:90]';
%         PI{4} = [91:120]';
%         PI{5} = [121:150]';
%         PI{6} = [151:180]';
%         PI{7} = [181:210]';
%         PI{8} = [211:240]';
%         PI{9} = [241:270]';
%         PI{10} = [271:300]';
%         PI{11} = [301:330]';
%         PI{12} = [331:360]';
%         PI{13} = [361:390]';
%         PI{14} = [391:420]';
%         PI{15} = [421:450]';
%         PI{16} = [451:480]';
%         PI{17} = [481:510]';
%         PI{18} = [511:540]';
%         PI{19} = [541:570]';
%         PI{20} = [571:600]';
%         PINumber{1} = [1];
%         PINumber{2} = [31];
%         PINumber{3} = [61];
%         PINumber{4} = [91];
%         PINumber{5} = [121];
%         PINumber{6} = [151];
%         PINumber{7} = [181];
%         PINumber{8} = [211];
%         PINumber{9} = [241];
%         PINumber{10} = [271];
%         PINumber{11} = [301];
%         PINumber{12} = [331];
%         PINumber{13} = [361];
%         PINumber{14} = [391];
%         PINumber{15} = [421];
%         PINumber{16} = [451];
%         PINumber{17} = [481];
%         PINumber{18} = [511];
%         PINumber{19} = [541];
%         PINumber{20} = [571];
%         PINumber{21} = [601];
%     end
    
%    if N == 600 %��ʽ��
%         PI{1} = [1:120]';
%         PI{2} = [121:240]';
%         PI{3} = [241:320]';
%         PI{4} = [321:480]';
%         PI{5} = [481:600]';
%         PINumber{1} = [1];
%         PINumber{2} = [121];
%         PINumber{3} = [241];
%         PINumber{4} = [321];
%         PINumber{5} = [481];
%         PINumber{6} = [601];
%     end

   if N == 600 %��ʽ��
        PI{1} = [1:150]';
        PI{2} = [151:300]';
        PI{3} = [301:450]';
        PI{4} = [451:600]';
        PINumber{1} = [1];
        PINumber{2} = [151];
        PINumber{3} = [301];
        PINumber{4} = [451];
        PINumber{5} = [601];
    end


    
else
    PI = cell(n,1);
    %%�����ǶԻ�������������
    % index = randint(1,N,[1 n]);
    % for j = 1:n
    %     index_j = find(index == j);
    %     PI{j} = index_j;
    % end
    
    
    %�����ǶԻ�����н�����Ȼ���
    for j = 1:n
        PI{j} = [j:n:N]';
    end
    
end

PI = PI';

allNodes = [];
for i = 1:size(PI,1)
    allNodes = [allNodes; PI{i}];
end

